#!/bin/bash

   aPort="3000"   # default if not in file, _env
   aStg="client2"
   aApp="c24_login-form-app"
   aRepo="IODD_/dev1-login"
   aMode="dev"    # or start for prod, or build

   aRepo="/webs/${aRepo}"
   aNext="${aRepo}/${aStg}/node_modules/.bin/next"

if [ -f  "_env" ]; then aRegX="^ *([Cc]lient_)*(PORT|Port|port) *= *"
   aPgm='/^#|([Ss]erv)/{next}; /'${aRegX}'[0-9]{4,5}/ { sub( /'${aRegX}'/, "" )'
   nPort=$( cat "_env" | awk "${aPgm}; print; exit }" ); # echo "${nPort}"; exit
if [ "${nPort}" != "" ]; then aPort=${nPort}; fi; fi
if [ "$1" != "" ]; then aPort="$1"; fi

     cd        "${aRepo}/${aStg}/${aApp}"
   echo -e "\n  ${aRepo}/${aStg}/${aApp}"
   echo      "  next ${aMode} -p ${aPort}"
   echo "------------------------------------------------------------------------------------"
   echo ""

#  chrome "http://localhost:${aPort}"

 ${aNext} ${aMode} -p ${aPort}


