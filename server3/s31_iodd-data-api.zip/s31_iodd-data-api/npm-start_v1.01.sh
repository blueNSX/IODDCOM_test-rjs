#!/bin/bash

   aPort="3013"    # if not in $1 or .env
   aStg="server3"
   aApp="s31_iodd-data-api"
   aRepo="IODD_/prod-master_v30428-et217p,wiForms"
#  aMode="dev"    # or start for prod, or build

   aRepo="C:/WEBs/8020/VMs/et217p_formR0/webs/${aRepo}"
   aPath="${aRepo}/${aStg}/${aApp}"

#  aPath="$(realpath "$0")"; aPath="${aPath/\/npm-start.sh/}"; # echo "  ${aPath}"

if [ "${aStg:0:6}" == "server" ]; then aEnv="${aPath}/api/.env"; else aEnv="${aPath}/_env"; fi 
if [ "${aStg:0:6}" == "server" ]; then aStg1="[Ss]erver_"; aStg2="[Cc]lient_"; 
                                  else aStg1="[Cc]lient_"; aStg2="[Ss]erver_"; fi 
if [ -e "${aEnv}" ]; then bOK="found"; else bOK="not found"; fi; echo "${bOK}"; # exit;     
#   cat "${aEnv}"; echo "--------"; echo "aEnv: '${aEnv}'"; # exit 
if [ -e "${aEnv}" ]; then aRegX="^ *(${aStg1})*(PORT|Port|port) *= *"
   aPgm='/^#|('${aStg2}')/{next}; /'${aRegX}'[0-9]{4,5}/ { sub( /'${aRegX}'/, "" )'; echo "aPgm: '${aPgm}'"; # exit 
   nPort=$( cat "${aEnv}" | awk "${aPgm}; print; exit }" );   echo " Port ${nPort} in ${aEnv}"; exit
if [ "${nPort}" != "" ]; then aPort=${nPort}; fi; fi
if [ "$1" != ""       ]; then aPort="$1"; fi

   cd    "${aPath}"
 echo  "  ${aPath}"
 echo  "  nodemon server.mjs ${aPort}"
 echo "------------------------------------------------------------------------------------"
#echo ""
 exit 

  chrome  http://localhost:${aPort} 
 nodemon  server.mjs ${aPort}


